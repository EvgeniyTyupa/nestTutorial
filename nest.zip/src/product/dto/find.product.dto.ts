export class FindProductDto{
    category: string;
    limit: number;
}